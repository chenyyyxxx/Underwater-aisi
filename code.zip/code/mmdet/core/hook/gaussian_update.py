from mmcv.runner.hooks import HOOKS, Hook
import numpy as np
import time

@HOOKS.register_module()
class GaussianUpdateHook(Hook):
    """"""
    def after_train_iter(self, runner):
        iter = runner.iter
        if iter % 3 == 0:
            model = runner.model.module
            header=model.bbox_head.pseudo_rpn_head
            queue_prototypes=header.queue
            header.prototypes_mu=queue_prototypes[-1][0]
            header.prototypes_delta=queue_prototypes[-1][1]

    def after_train_epoch(self, runner,path="work_dirs/variables"):
        epoch=runner.epoch
        if epoch % 1 == 0:
            model = runner.model.module
            header=model.bbox_head.pseudo_rpn_head
            mu=header.prototypes_mu.to("cpu").numpy()
            delta=header.prototypes_delta.to("cpu").numpy()
            # t=time.time()
            np.save("{}/mu_{}.npy".format(path,epoch),mu)
            np.save("{}/delta_{}.npy".format(path, epoch), delta)
            # print('')
