import numpy as np
import os

class RunningVariable():
    def __init__(self,path='work_dirs/variables',
                 score_file='scores.npy',
                 dynamic_th='dyanmic_th.npy'):
        """"""
        if not os.path.exists(path):
            os.mkdir(path)
        self.score_path=path+"/"+score_file
        self.dynamic_path=path+"/"+dynamic_th
        if not os.path.exists(self.score_path):
            np.save(self.score_path,np.zeros((1,)))
        if not os.path.exists(self.dynamic_path):
            np.save(self.dynamic_path,np.zeros((1,)))

    def load(self,path):
        data=np.load(path)
        return data

    def save(self,path,values):
        np.save(path,values)

    def update_scores(self,scores):
        scores=scores.flatten()
        data=self.load(self.score_path)
        data=np.concatenate((data,scores),axis=0)
        self.save(self.score_path,data)
    def update_threshold(self,th):
        th=np.array(th).reshape((1,))
        data=self.load(self.dynamic_path)
        data = np.concatenate((data, th), axis=0)
        self.save(self.dynamic_path,data)